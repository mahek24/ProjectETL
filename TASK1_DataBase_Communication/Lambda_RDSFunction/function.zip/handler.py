import json
import pymysql
from sqlalchemy import create_engine, MetaData, Table, select

def lambda_handler(event, context):
    # Define your database connection parameters
    db_user = 'admin'
    db_password = 'POLKmn1234'
    db_host = 'database-1.c7ku4kqu4mf9.us-east-1.rds.amazonaws.com'
    db_name = 'user_data'

    # Connection string
    engine = create_engine(f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}')

    # Create connection
    connection = engine.connect()

    try:
        # Define metadata and reflect tables
        metadata = MetaData()
        users_table = Table('users', metadata, autoload_with=engine)

        # Select all records from 'users' table
        query = select([users_table])
        result = connection.execute(query)

        # Fetch all results
        users = [dict(row) for row in result]

        # Return results as a JSON object
        return {
            "statusCode": 200,
            "body": json.dumps(users)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    finally:
        # Close the connection
        connection.close()
